<?php
	get_template_part( 'templates/footer/index' );
	wp_footer();
?>

</body>
</html>
