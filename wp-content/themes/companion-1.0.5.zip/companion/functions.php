<?php
// Product Registration
define( 'STM_THEME_NAME', 'Companion' );
define( 'STM_THEME_CATEGORY', 'Business, Consulting, Finance WordPress Theme' );
define( 'STM_ENVATO_ID', '39413480' );
define( 'STM_TOKEN_OPTION', 'stm_companion_token' );
define( 'STM_TOKEN_CHECKED_OPTION', 'stm_companion_token_checked' );
define( 'STM_THEME_SETTINGS_URL', 'companion_settings' );
define( 'STM_GENERATE_TOKEN', 'https://docs.stylemixthemes.com/companion-theme-documentation/getting-started/theme-activation' );
define( 'STM_SUBMIT_A_TICKET', 'https://support.stylemixthemes.com/tickets/new/support?item_id=39' );
define( 'STM_DEMO_SITE_URL', 'https://companion.stylemixthemes.com/' );
define( 'STM_DOCUMENTATION_URL', 'https://docs.stylemixthemes.com/companion-theme-documentation/' );
define( 'STM_CHANGELOG_URL', 'https://docs.stylemixthemes.com/companion-theme-documentation/extra-materials/changelog' );
define( 'STM_INSTRUCTIONS_URL', 'https://docs.stylemixthemes.com/companion-theme-documentation/installation-and-activation/theme-activation' );
define( 'STM_INSTALL_VIDEO_URL', 'https://www.youtube.com/watch?v=Z3OKcu9yHjQ&list=PL3Pyh_1kFGGCwD2aaNcFGJ8H2sWhSjG0a&ab_channel=StylemixThemes' );
define( 'STM_VOTE_URL', 'https://stylemixthemes.cnflx.io/boards/companion-wordpress-theme-for-business-consulting' );
define( 'STM_VIDEO_TUTORIALS', 'https://www.youtube.com/watch?v=Z3OKcu9yHjQ&list=PL3Pyh_1kFGGCwD2aaNcFGJ8H2sWhSjG0a&ab_channel=StylemixThemes' );
define( 'STM_FACEBOOK_COMMUNITY', 'https://www.facebook.com/stylemixthemes/' );
define( 'STM_THEME_VERSION', ( WP_DEBUG ) ? time() : wp_get_theme()->get( 'Version' ) );
define( 'STM_THEME_PATH', dirname( __FILE__ ) );
define( 'STM_INCLUDES_PATH', STM_THEME_PATH . '/includes' );
define( 'STM_TEMPLATE_URI', get_template_directory_uri() );
define( 'STM_TEMPLATE_DIR', get_template_directory() );

require_once STM_INCLUDES_PATH . '/custom-functions.php';
require_once STM_INCLUDES_PATH . '/enqueue.php';
require_once STM_INCLUDES_PATH . '/comments.php';
require_once STM_INCLUDES_PATH . '/theme-config.php';

if ( class_exists( 'WooCommerce' ) ) {
	require_once STM_INCLUDES_PATH . '/woocommerce.php';
}

if ( is_admin() && file_exists( get_template_directory() . '/admin/admin.php' ) ) {
	require_once get_template_directory() . '/admin/admin.php';
	require_once STM_INCLUDES_PATH . '/importer/init.php';
}
