<?php get_header(); ?>

<div id="wrapper" class="wrapper">
	<div class="container">
		<?php
		if ( 'post' === get_post_type() ) {
			if ( file_exists( get_template_directory() . '/templates/single/post/index.php' ) ) {
				get_template_part( 'templates/single/post/index' );
			}
		} else {
			while ( have_posts() ) :
				the_post();
				the_content();
			endwhile;
		}
		?>
	</div>
</div>

<?php
get_footer();
