<?php
$custom_logo_id = companion_get_option( 'logo' );
$logo_image     = wp_get_attachment_image_src( $custom_logo_id, 'full' );
$logo_margin    = companion_get_option( 'logo_margin' );
$logo_indent    = ( $logo_margin ) ? 'margin: ' . $logo_margin['top'] . $logo_margin['unit'] . ' ' . $logo_margin['right'] . $logo_margin['unit'] . ' ' . $logo_margin['bottom'] . $logo_margin['unit'] . ' ' . $logo_margin['left'] . $logo_margin['unit'] . ';' : '';
$logo_width     = ( companion_get_option( 'logo_width' ) ) ? 'width=' . companion_get_option( 'logo_width' ) . ' ' : 'width=151 ';
$logo_height    = ( companion_get_option( 'logo_height' ) ) ? 'height=' . companion_get_option( 'logo_height' ) . ' ' : 'height=33 ';

if ( ! empty( $custom_logo_id ) ) { ?>
	<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="companion-logo">
		<img
			<?php
				echo esc_attr( $logo_width );
				echo esc_attr( $logo_height );
			?>
			src="<?php echo esc_url( $logo_image[0] ); ?>"
			alt="<?php echo esc_attr( get_the_title( $custom_logo_id ) ); ?>"
			style="<?php echo esc_attr( $logo_indent ); ?>">
	</a>
<?php } else { ?>
	<a href="<?php echo esc_url( site_url( '/' ) ); ?>" class="companion-logo">
		<img
			<?php
				echo esc_attr( $logo_width );
				echo esc_attr( $logo_height );
			?>
			src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/base/logo-default.png' ); ?>"
			alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>"
		/>
	</a>
	<?php
}
