<?php if ( ! is_404() ) : ?>
	<header class="header">
		<div class="container">
			<section class="navigation">
				<?php
					get_template_part( 'templates/header/parts/logo' );
					get_template_part( 'templates/header/parts/menu' );
				?>
			</section>
		</div>
	</header>
	<?php
endif;

