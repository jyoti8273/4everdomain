<div class="post-content">
	<div class="entry-content">
		<?php the_excerpt(); ?>
	</div>
</div>
