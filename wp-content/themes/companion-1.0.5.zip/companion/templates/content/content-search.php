<h1><?php esc_html_e( 'Search results:', 'companion' ); ?></h1>
<?php if ( have_posts() ) : ?>
	<div class="posts-template">
		<?php
		while ( have_posts() ) :
			the_post();
			?>
			<div class="news-list-item">
				<div class="news-list-content <?php echo has_post_thumbnail() ? 'image' : 'no-image'; ?>">
					<?php if ( has_post_thumbnail() ) : ?>
						<div class="news-list-item-image">
							<div class="news-list-post-categories">
								<ul>
									<?php
									$post_terms = get_the_category_list( '', '', get_the_ID() );
									echo wp_kses_post( $post_terms );
									?>
								</ul>
							</div>
							<?php if ( has_post_thumbnail() ) : ?>
								<a href="<?php the_permalink(); ?>" class="companion-post-thumbnail">
									<?php the_post_thumbnail( 'companion_post_image' ); ?>
								</a>
							<?php endif; ?>
						</div>
					<?php else : ?>
						<div class="no-image-news-list-post-categories">
							<ul>
								<?php
								$post_terms = get_the_category_list( '', '', get_the_ID() );
								echo wp_kses_post( $post_terms );
								?>
							</ul>
						</div>
					<?php endif; ?>
					<div class="news-list-content-info">
						<div class="post-content-area">
							<div class="news-list-item-title">
								<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
							</div>
							<div class="news-list-item-excerpt">
								<?php
								echo wp_kses_post( get_the_excerpt() );
								?>
							</div>
						</div>
						<a href="<?php the_permalink(); ?>" class="news-list-item-btn">
							<?php echo esc_html__( 'Learn more', 'companion' ); ?>
							<i aria-hidden="true" class="companion-icon-arrow-right"></i>
						</a>
					</div>
				</div>
			</div>
			<?php
		endwhile;
		companion_posts_pages_pagination( 'posts_pages_pagination' );
		wp_reset_postdata();
		?>
	</div>
<?php else : ?>
	<p><?php esc_html_e( 'Sorry, nothing was found', 'companion' ); ?></p>
<?php endif; ?>
