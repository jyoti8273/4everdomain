<?php
$copyright        = companion_get_option( 'copyright' );
$current_year     = companion_get_option( 'current_year' );
$copyright_symbol = companion_get_option( 'copyright_symbol' );
?>
<footer class="footer">
	<div class="container">
		<?php if ( ! empty( $copyright ) ) : ?>
		<div class="copyright">
			<?php
			if ( true === $copyright_symbol ) {
				echo '&copy;';
			}
			if ( true === $current_year ) {
				echo esc_html( gmdate( 'Y' ) );
			}
			echo wp_kses_post( $copyright );
			?>
		</div>
		<?php endif; ?>
	</div>
</footer>
