<?php if ( have_posts() ) : ?>
<div class="pages-template">
	<div class="container">
		<?php
		while ( have_posts() ) {
			the_post();
			do_action( 'companion_woocommerce_breadcrumb' );
			$title_status = get_post_meta( get_the_ID(), 'page_title_status', true );
			if ( 'on' === $title_status || ! metadata_exists( 'post', get_the_ID(), 'page_title_status' ) ) {
				the_title( '<h1 class="page-title">', '</h1>' );
			}
			?>
			<section class="page-content">
				<div class="entry-content">
					<?php the_content(); ?>
				</div>
			</section>
			<?php
			get_template_part( 'templates/page/parts/next-page' );
			get_template_part( 'templates/page/parts/comments' );
			?>
		<?php } ?>
	</div>
</div>
<?php endif; ?>
