<?php
get_template_part( 'templates/single/post/parts/prev-next-buttons' );
get_template_part( 'templates/single/post/parts/comments' );
