<div class="single-post-content">
	<div class="entry-content">
		<?php the_content(); ?>
	</div>
</div>
