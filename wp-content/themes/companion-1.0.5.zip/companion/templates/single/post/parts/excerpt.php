<?php if ( has_excerpt() ) : ?>
	<div class="single-post-excerpt">
		<?php the_excerpt(); ?>
	</div>
<?php endif; ?>
