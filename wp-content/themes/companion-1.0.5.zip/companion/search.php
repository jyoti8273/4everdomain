<?php get_header(); ?>

<div id="wrapper" class="wrapper">
	<div class="container">
		<?php get_template_part( 'templates/content/content', 'search' ); ?>
	</div>
</div>

<?php
get_footer();
