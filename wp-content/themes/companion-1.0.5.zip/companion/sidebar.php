<?php
$settings = get_option( 'stm_theme_settings', array() );

$sidebar = ! empty( $settings['post-sidebar'] ) ? $settings['post-sidebar'] : 'primary-sidebar';
if ( is_singular( 'post' ) ) {
	$sidebar = ! empty( $settings['single-posts-sidebar'] ) ? $settings['single-posts-sidebar'] : 'primary-sidebar';
}

if ( 'product' !== get_post_type() && ! is_post_type_archive( 'product' ) ) {
	dynamic_sidebar( $sidebar );
}
