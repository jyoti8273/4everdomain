<?php get_header(); ?>
	<div id="wrapper" class="wrapper">
		<?php get_template_part( 'templates/' . get_post_type() . '/index' ); ?>
	</div>
<?php
get_footer();
