## 1.0.5
- **New:** [Strategy Consultants](https://companion.stylemixthemes.com/strategy-consultants/) Demo.
- **Added:** New Portfolio style - Panel.
- **Update:** Companion Configurations Plugin is updated to v1.0.3.
- **Update:** Companion Elementor Widgets Plugin is updated to v1.0.4.
- **Fixed:** Price filter widget is not displayed on the Shop sidebar after demo import.

## 1.0.4
- **Update:** Companion Elementor Widgets Plugin is updated to v1.0.3.
- **Update:** Compatibility update with Elementor v3.7.7.

## 1.0.3
- **New:** [Business Consultant](https://companion.stylemixthemes.com/business-consultant/) Demo.
- **Update:** Companion Configurations Plugin is updated to v1.0.2.
- **Update:** Companion Elementor Widgets Plugin is updated to v1.0.2.
- **Fixed:** The cart widget threw an error when the WooCommerce plugin disabled.
- **Fixed:** Minor bugs.

## 1.0.2
- **Update:** Companion Configurations Plugin is updated to v1.0.1.
- **Update:** Companion Elementor Widgets Plugin is updated to v1.0.1.
- **Added:** Inline view for Post Navigation Widget.
- **Added:** Responsive mode for Title Alignment option on News Grid Widget.
- **Fixed:** Hover effect of the Portfolio List Widget is not properly working in Safari.
- **Fixed:** Title Color option not worked in Icon Box Widget.
- **Fixed:** When hovered over a post image, the hover effect worked on images of other posts on the News Grid widget.
- **Fixed:** When Title Tag changed, the styles were lost in the News Grid widget.
- **Fixed:** When adding multiple Blockquote widgets on the same page, the icon positioning settings affect all added Blockquote widgets.
- **Fixed:** Title Color and Title Hover Color options not applied in Case Banners Widget.
- **Fixed:** Changes on Case Banners did not apply Elementor editing mode.
- **Fixed:** Team Carousel items are disappeared when item spacing is not set in Widget settings.
- **Fixed:** Minor bugs.

## 1.0.1
- **Fixed:** Minor bug fixes.

## 1.0.0
- Theme Release.