"use strict";

window.addEventListener("load", function () {
  document.getElementById("companion-preloader").remove();
});