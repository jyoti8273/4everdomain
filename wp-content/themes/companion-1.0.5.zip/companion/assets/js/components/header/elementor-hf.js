"use strict";

(function ($) {
  $(document).ready(function () {
    $("header [data-elementor-id!=''][data-elementor-id]").each(function () {
      var id = $(this).attr('data-elementor-id');
      header_position_desktop(window["companion_ehf_position_desktop_".concat(id)]);
      header_position_tablet(window["companion_ehf_position_tablet_".concat(id)]);
      header_position_mobile(window["companion_ehf_position_mobile_".concat(id)]);
    });
    responsiveSubMenu();
  });

  function header_position_desktop(settings) {
    var $selector = $('body');
    if (!$selector.length) return false;
    if (settings['header_position_desktop'] === 'relative') $selector.addClass('companion-ehf-desktop-relative');
    if (settings['header_position_desktop'] === 'absolute') $selector.addClass('companion-ehf-desktop-absolute');
    if (settings['header_position_desktop'] === 'sticky') $selector.addClass('companion-ehf-desktop-sticky');
    if (settings['header_position_desktop'] === 'fixed') $selector.addClass('companion-ehf-desktop-fixed');
  }

  function header_position_tablet(settings) {
    var $selector = $('body');
    if (!$selector.length) return false;
    if (settings['header_position_tablet'] === 'relative') $selector.addClass('companion-ehf-tablet-relative');
    if (settings['header_position_tablet'] === 'absolute') $selector.addClass('companion-ehf-tablet-absolute');
    if (settings['header_position_tablet'] === 'sticky') $selector.addClass('companion-ehf-tablet-sticky');
    if (settings['header_position_tablet'] === 'fixed') $selector.addClass('companion-ehf-tablet-fixed');
  }

  function header_position_mobile(settings) {
    var $selector = $('body');
    if (!$selector.length) return false;
    if (settings['header_position_mobile'] === 'relative') $selector.addClass('companion-ehf-mobile-relative');
    if (settings['header_position_mobile'] === 'absolute') $selector.addClass('companion-ehf-mobile-absolute');
    if (settings['header_position_mobile'] === 'sticky') $selector.addClass('companion-ehf-mobile-sticky');
    if (settings['header_position_mobile'] === 'fixed') $selector.addClass('companion-ehf-mobile-fixed');
  }

  function responsiveSubMenu() {
    var subMenuFirstLvl = document.querySelectorAll('.hfe-nav-menu nav > ul > li > .sub-menu');
    var subMenuSecondLvl = document.querySelectorAll('.hfe-nav-menu nav > ul > li > .sub-menu > li > .sub-menu');
    var screenWidth = document.documentElement.clientWidth;

    if ($(window).width() > 1024) {
      subMenuFirstLvl.forEach(function (el) {
        if (el.getBoundingClientRect().right + 20 > screenWidth) {
          el.style.left = "unset";
          el.style.right = "0";
        }

        if (el.getBoundingClientRect().right + el.offsetWidth < screenWidth) {
          el.style.left = null;
          el.style.right = null;
        }
      });
      subMenuSecondLvl.forEach(function (el) {
        var subMenuInternalLvl = el.querySelectorAll('.sub-menu');

        if (subMenuInternalLvl.length !== 0) {
          var checkFit = function checkFit(items) {
            items.forEach(function (item) {
              if (item.getBoundingClientRect().right + 20 > screenWidth) {
                fit = false;
              }

              if (item.style.left !== '' && el.getBoundingClientRect().right - item.getBoundingClientRect().left + el.offsetWidth > screenWidth - el.getBoundingClientRect().right) {
                fit = false;
              }
            });
            return fit;
          };

          var fit = true;
          checkFit(subMenuInternalLvl);

          if (false === fit) {
            el.style.left = "-" + el.offsetWidth + "px";
            subMenuInternalLvl.forEach(function (el) {
              el.style.left = "-" + el.offsetWidth + "px";
            });
          }

          checkFit(subMenuInternalLvl);

          if (true === fit) {
            el.style.left = null;
            subMenuInternalLvl.forEach(function (el) {
              el.style.left = null;
            });
          }

          checkFit(subMenuInternalLvl);
        } else {
          if (el.getBoundingClientRect().right + 20 > screenWidth) {
            el.style.left = "-" + el.offsetWidth + "px";
          }

          if (el.style.left !== '' && el.getBoundingClientRect().right + el.offsetWidth * 2 < screenWidth) {
            el.style.left = null;
          }
        }
      });
    } else {
      subMenuFirstLvl.forEach(function (el) {
        el.style.left = null;
        el.style.right = null;
      });
      subMenuSecondLvl.forEach(function (el) {
        var subMenuLowerLvl = el.querySelectorAll('.sub-menu');
        el.style.left = null;
        subMenuLowerLvl.forEach(function (el) {
          el.style.left = "-" + el.offsetWidth + "px";
        });
      });
    }
  }

  window.addEventListener("resize", function () {
    responsiveSubMenu();
  });
})(jQuery);