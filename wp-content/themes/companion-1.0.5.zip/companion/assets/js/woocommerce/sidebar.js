"use strict";

(function () {
  "use strict";

  document.addEventListener("DOMContentLoaded", function () {
    var sidebarSelector = jQuery('.companion-wc-sidebar.sticky-sidebar');

    if (sidebarSelector.length) {
      var sidebar = new StickySidebar('.companion-wc-sidebar.sticky-sidebar', {
        containerSelector: ".companion-wc-shop",
        topSpacing: 50,
        resizeSensor: true,
        minWidth: 1025
      });
    }
  });
})();