"use strict";

(function () {
  "use strict";

  document.addEventListener("DOMContentLoaded", function () {
    var dropdownMenus = document.querySelectorAll('.wc-block-product-categories-list-item .wc-block-product-categories-list');
    dropdownMenus.forEach(function (el) {
      var icon = document.createElement("i");
      icon.className = "companion-icon-chevron-down";
      el.parentElement.classList.add("menu-item-has-children");
      el.parentElement.prepend(icon);
    });
    jQuery('.menu-item-has-children > i').click(function () {
      jQuery(this).parent().toggleClass('submenu-open');
      jQuery(this).siblings('.wc-block-product-categories-list').slideToggle();
    });
  });
})();