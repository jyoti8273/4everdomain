"use strict";

(function () {
  "use strict";

  document.addEventListener("DOMContentLoaded", function () {
    var quantityIncButton = jQuery('.quantity-input-inc');
    var quantityDecButton = jQuery('.quantity-input-dec');
    quantityIncButton.click(function () {
      this.parentNode.querySelector('input').stepUp();
    });
    quantityDecButton.click(function () {
      this.parentNode.querySelector('input').stepDown();
    });
  });
})();