<?php

if ( ! function_exists( 'companion_styles_and_scripts' ) && ! is_admin() ) {
	function companion_styles_and_scripts() {

		/*Styles*/
		wp_enqueue_style( 'companion-style', get_stylesheet_uri(), array(), STM_THEME_VERSION );
		wp_enqueue_style( 'companion-base', STM_TEMPLATE_URI . '/assets/css/styles.css', array(), STM_THEME_VERSION );
		wp_enqueue_style( 'google-fonts', companion_theme_fonts(), array(), STM_THEME_VERSION );
		wp_enqueue_style( 'liner-icons', STM_TEMPLATE_URI . '/assets/icons/linearicons/linear-icons.css', array(), STM_THEME_VERSION );
		wp_enqueue_style( 'companion-icons', STM_TEMPLATE_URI . '/assets/icons/companion-icons/style.css', array(), STM_THEME_VERSION );

		wp_add_inline_style( 'companion-style', companion_color_styles() );

		$custom_css = companion_get_option( 'custom_css' );

		if ( $custom_css ) {
			$custom_css = preg_replace( '/\s+/', ' ', $custom_css );
		}

		wp_add_inline_style( 'companion-base', $custom_css );

		wp_register_style( 'companion-404', STM_TEMPLATE_URI . '/assets/css/components/pages/404.css', array(), STM_THEME_VERSION );
		wp_register_style( 'companion-navigation', STM_TEMPLATE_URI . '/assets/css/components/header/navigation.css', array(), STM_THEME_VERSION );
		wp_enqueue_style( 'companion-navigation' );
		wp_register_style( 'companion-single-post', STM_TEMPLATE_URI . '/assets/css/components/post/single/single-post.css', array(), STM_THEME_VERSION );
		wp_register_style( 'companion-posts-list', STM_TEMPLATE_URI . '/assets/css/components/post/archive/posts-list.css', array(), STM_THEME_VERSION );
		wp_register_style( 'companion-posts-grid', STM_TEMPLATE_URI . '/assets/css/components/post/archive/posts-grid.css', array(), STM_THEME_VERSION );
		wp_register_style( 'companion-comments', STM_TEMPLATE_URI . '/assets/css/components/comments/comments.css', array(), STM_THEME_VERSION );
		wp_register_style( 'companion-woocommerce', STM_TEMPLATE_URI . '/assets/css/woocommerce/woocommerce.css', array(), STM_THEME_VERSION );
		wp_register_style( 'companion-cost-calc', STM_TEMPLATE_URI . '/assets/css/cost-calculator/cost-calc.css', array(), STM_THEME_VERSION );

		/*Scripts*/
		wp_register_script( 'companion-header', STM_TEMPLATE_URI . '/assets/js/components/header/header.js', array( 'jquery' ), STM_THEME_VERSION, true );
		wp_register_script( 'companion-preloader', STM_TEMPLATE_URI . '/assets/js/components/preloader.js', array( 'jquery' ), STM_THEME_VERSION, true );
		wp_register_script( 'companion-sticky-sidebar', STM_TEMPLATE_URI . '/assets/vendors/sticky-sidebar/sticky-sidebar.js', array( 'jquery' ), STM_THEME_VERSION, true );
		wp_register_script( 'companion-resize-sensor', STM_TEMPLATE_URI . '/assets/vendors/sticky-sidebar/ResizeSensor.js', array( 'jquery' ), STM_THEME_VERSION, true );
		wp_register_script( 'companion-woocommerce-sidebar', STM_TEMPLATE_URI . '/assets/js/woocommerce/sidebar.js', array( 'jquery' ), STM_THEME_VERSION, true );
		wp_register_script( 'companion-woocommerce-dropdown-menu', STM_TEMPLATE_URI . '/assets/js/woocommerce/dropdown-menu.js', array( 'jquery' ), STM_THEME_VERSION, true );
		wp_register_script( 'companion-woocommerce-fields', STM_TEMPLATE_URI . '/assets/js/woocommerce/fields.js', array( 'jquery' ), STM_THEME_VERSION, true );
		wp_register_script( 'companion-elementor-hf', STM_TEMPLATE_URI . '/assets/js/components/header/elementor-hf.js', array( 'jquery' ), STM_THEME_VERSION, true );

		wp_enqueue_script( 'companion-header' );

		if ( companion_get_option( 'preloader' ) ) {
			wp_enqueue_script( 'companion-preloader' );
		}

		if ( is_single() ) {
			wp_enqueue_style( 'companion-single-post' );
		}

		if ( ( is_archive() || is_author() || is_category() || is_tag() || is_home() ) && 'post' === get_post_type() ) {
			wp_enqueue_style( 'companion-posts-list' );
			wp_enqueue_style( 'companion-posts-grid' );
		}

		if ( is_search() ) {
			wp_enqueue_style( 'companion-posts-list' );
		}

		if ( is_404() ) {
			wp_enqueue_style( 'companion-404' );
		}

		if ( is_singular() ) {
			wp_enqueue_script( 'comment-reply' );
			wp_enqueue_style( 'companion-comments' );
		}

		if ( class_exists( 'WooCommerce' ) ) {
			if ( is_woocommerce() || is_cart() || is_checkout() || is_account_page() || defined( 'YITH_WCWL' ) && yith_wcwl_is_wishlist_page() ) {
				wp_enqueue_style( 'companion-woocommerce' );
				wp_enqueue_script( 'companion-sticky-sidebar' );
				wp_enqueue_script( 'companion-resize-sensor' );
				wp_enqueue_script( 'companion-woocommerce-sidebar' );
				wp_enqueue_script( 'companion-woocommerce-dropdown-menu' );
				wp_enqueue_script( 'companion-woocommerce-fields' );
			}
		}

		if ( defined( 'CALC_VERSION' ) ) {
			wp_enqueue_style( 'companion-cost-calc' );
		}

		if ( defined( 'HFE_DIR' ) ) {
			wp_enqueue_script( 'companion-elementor-hf' );
		}
	}
}

add_action( 'wp_enqueue_scripts', 'companion_styles_and_scripts', 100 );

if ( ! function_exists( 'companion_admin_styles_and_scripts' ) && is_admin() ) {
	function companion_admin_styles_and_scripts() {

		/*Styles*/
		wp_enqueue_style( 'admin-dashboard', STM_TEMPLATE_URI . '/assets/admin/css/dashboard.css', array(), STM_THEME_VERSION );
	}
}

add_action( 'admin_enqueue_scripts', 'companion_admin_styles_and_scripts', 100 );

if ( ! function_exists( 'companion_move_jquery_into_footer' ) ) {
	function companion_move_jquery_into_footer( $wp_scripts ) {

		if ( is_admin() ) {
			return;
		}

		$wp_scripts->add_data( 'jquery', 'group', 1 );
		$wp_scripts->add_data( 'jquery-core', 'group', 1 );
		$wp_scripts->add_data( 'jquery-migrate', 'group', 1 );
	}
}

add_action( 'wp_default_scripts', 'companion_move_jquery_into_footer' );
