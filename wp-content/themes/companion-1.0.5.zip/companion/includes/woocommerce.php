<?php
/**
 * WooCommerce setup function.
 */
if ( ! function_exists( 'companion_wc_setup' ) ) {
	function companion_wc_setup() {
		add_theme_support(
			'woocommerce',
			array(
				'thumbnail_image_width' => 370,
				'single_image_width'    => 548,
			)
		);
		add_theme_support( 'wc-product-gallery-zoom' );
		add_theme_support( 'wc-product-gallery-lightbox' );
		add_theme_support( 'wc-product-gallery-slider' );
	}
}

add_action( 'after_setup_theme', 'companion_wc_setup' );

/**
 * Change the breadcrumb separator
 */
if ( ! function_exists( 'companion_wc_breadcrumb_delimiter' ) ) {
	function companion_wc_breadcrumb_delimiter( $defaults ) {
		$defaults['delimiter'] = ' > ';

		return $defaults;
	}
}

add_filter( 'woocommerce_breadcrumb_defaults', 'companion_wc_breadcrumb_delimiter' );

/**
 * WooCommerce breadcrumbs
 */
if ( ! function_exists( 'companion_wc_breadcrumbs' ) ) {
	function companion_wc_breadcrumbs() {
		if ( class_exists( 'WooCommerce' ) ) {
			if ( is_cart() || is_checkout() || is_account_page() || defined( 'YITH_WCWL' ) && yith_wcwl_is_wishlist_page() ) {
				woocommerce_breadcrumb();
			}
		}
	}
}

add_action( 'companion_woocommerce_breadcrumb', 'companion_wc_breadcrumbs' );

/**
 * Quantity input customization
 */
if ( ! function_exists( 'companion_wc_before_quantity_input_field' ) ) {
	function companion_wc_before_quantity_input_field() {
		echo '<label class="quantity-label">' . esc_html__( 'Quantity', 'companion' ) . '</label>';
		echo '<div class="quantity-input">';
		echo '<span class="quantity-input-inc"><i class="companion-icon-chevron-top"></i></span>';
		echo '<span class="quantity-input-dec"><i class="companion-icon-chevron-down"></i></span>';
	}
}

add_action( 'woocommerce_before_quantity_input_field', 'companion_wc_before_quantity_input_field' );

if ( ! function_exists( 'companion_wc_after_quantity_input_field' ) ) {
	function companion_wc_after_quantity_input_field() {
		echo '</div>';
	}
}

add_action( 'woocommerce_after_quantity_input_field', 'companion_wc_after_quantity_input_field' );

/**
 * Remove titles from tab panels
 */
add_filter( 'woocommerce_product_description_heading', '__return_null' );
add_filter( 'woocommerce_product_additional_information_heading', '__return_null' );

/**
 * Remove rating from loop
 */
remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_rating', 5 );

/**
 * Pagination arrows icon
 */
if ( ! function_exists( 'companion_wc_pagination_icons' ) ) {
	function companion_wc_pagination_icons( $args ) {
		$args['prev_text'] = '<i class="companion-icon-arrow-left"></i>';
		$args['next_text'] = '<i class="companion-icon-arrow-right"></i>';

		return $args;
	}
}

add_filter( 'woocommerce_pagination_args', 'companion_wc_pagination_icons' );

/**
 * Loop product item structure
 */
remove_action( 'woocommerce_before_shop_loop_item', 'woocommerce_template_loop_product_link_open', 10 );

if ( ! function_exists( 'companion_wc_before_thumbnail' ) ) {
	function companion_wc_before_thumbnail() {
		echo '<div class="companion-wc-thumbnail-wrapper">';
	}
}

add_action( 'woocommerce_before_shop_loop_item_title', 'companion_wc_before_thumbnail', 9 );
add_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_link_open', 9 );

if ( ! function_exists( 'companion_wc_product_buttons_open' ) ) {
	function companion_wc_product_buttons_open() {
		echo '<div class="companion-wc-product-buttons">';
		if ( defined( 'YITH_WCWL' ) ) {
			echo do_shortcode( '[yith_wcwl_add_to_wishlist]' );
		}
		echo '<div class="companion-wc-add-to-cart">';
	}
}

add_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_link_close', 11 );
add_action( 'woocommerce_before_shop_loop_item_title', 'companion_wc_product_buttons_open', 11 );
add_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_add_to_cart', 11 );

if ( ! function_exists( 'companion_wc_product_buttons_close' ) ) {
	function companion_wc_product_buttons_close() {
		echo '</div>';
		echo '</div>';
	}
}

add_action( 'woocommerce_before_shop_loop_item_title', 'companion_wc_product_buttons_close', 11 );

if ( ! function_exists( 'companion_wc_after_thumbnail' ) ) {
	function companion_wc_after_thumbnail() {
		echo '</div>';
	}
}

add_action( 'woocommerce_before_shop_loop_item_title', 'companion_wc_after_thumbnail', 11 );
remove_action( 'woocommerce_shop_loop_item_title', 'woocommerce_template_loop_product_title', 10 );
add_action( 'woocommerce_shop_loop_item_title', 'companion_wc_template_loop_product_title', 10 );

if ( ! function_exists( 'companion_wc_template_loop_product_title' ) ) {
	function companion_wc_template_loop_product_title() {
		echo '<h2 class="' . esc_attr( apply_filters( 'woocommerce_product_loop_title_classes', 'woocommerce-loop-product__title' ) ) . '"><a href="' . esc_url( get_permalink() ) . '">' . esc_html( get_the_title() ) . '</a></h2>';
	}
}

remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10 );
remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_product_link_close', 5 );

/**
 * Enable Gutenberg editor for products
 */
if ( ! function_exists( 'companion_wc_gutenberg_editor_enable' ) ) {
	function companion_wc_gutenberg_editor_enable( $can_edit, $post_type ) {
		if ( 'product' === $post_type ) {
			$can_edit = true;
		}

		return $can_edit;
	}
}

add_filter( 'use_block_editor_for_post_type', 'companion_wc_gutenberg_editor_enable', 10, 2 );

/**
 * Sidebar
 */
if ( ! function_exists( 'companion_wc_sidebar' ) ) {
	function companion_wc_sidebar( $sidebar = '' ) {
		if ( empty( $sidebar ) ) {
			return;
		}

		$sidebar_classes = 'companion-wc-sidebar';
		$sidebar_sticky  = companion_get_option( 'shop_sidebar_sticky', false );

		if ( $sidebar_sticky ) {
			$sidebar_classes .= ' sticky-sidebar';
		}

		if ( is_active_sidebar( $sidebar ) ) {
			?>
			<aside class="<?php echo esc_attr( $sidebar_classes ); ?>" data-sticky="true" id="companion-wc-sidebar">
				<?php dynamic_sidebar( $sidebar ); ?>
			</aside>
			<?php
		}
	}
}

/**
 * Override sidebar position with get query
 */
if ( ! function_exists( 'companion_wc_override_sidebar_position' ) ) {
	function companion_wc_override_sidebar_position( $sidebar_position ) {
		$check_values = array( 'none', 'left', 'right' );

		if ( ! empty( $_GET['sidebar_position'] ) && in_array( $_GET['sidebar_position'], $check_values ) ) { // phpcs:ignore
			$sidebar_position = $_GET['sidebar_position']; // phpcs:ignore
		}

		return $sidebar_position;
	}
}

add_filter( 'companion_wc_sidebar_position', 'companion_wc_override_sidebar_position', 100 );

/**
 * Shop Loop Customization
 */
if ( ! function_exists( 'companion_wc_before_shop_loop' ) ) {
	function companion_wc_before_shop_loop() {
		$sidebar          = companion_get_option( 'shop_sidebar' );
		$sidebar_position = companion_get_option( 'shop_sidebar_position' );
		$sidebar_position = apply_filters( 'companion_wc_sidebar_position', $sidebar_position );
		$class            = 'companion-wc-shop';
		$class           .= ' sidebar-' . $sidebar_position;
		?>
		<div class="<?php echo esc_attr( $class ); ?>">
		<?php
		if ( 'left' === $sidebar_position ) {
			companion_wc_sidebar( $sidebar );
		}
		?>
		<div class="companion-wc-products">
		<?php
	}
}

add_action( 'woocommerce_before_shop_loop', 'companion_wc_before_shop_loop' );

if ( ! function_exists( 'companion_wc_after_shop_loop' ) ) {
	function companion_wc_after_shop_loop() {
		$sidebar          = companion_get_option( 'shop_sidebar' );
		$sidebar_position = companion_get_option( 'shop_sidebar_position' );
		$sidebar_position = apply_filters( 'companion_wc_sidebar_position', $sidebar_position );
		?>
		</div>
		<?php
		if ( 'right' === $sidebar_position ) {
			companion_wc_sidebar( $sidebar );
		}
		?>
		</div>
		<?php
	}
}

add_action( 'woocommerce_after_shop_loop', 'companion_wc_after_shop_loop', 11 );
/**
 * Change number of products that are displayed per page (shop page)
 */
if ( ! function_exists( 'companion_wc_loop_shop_per_page' ) ) {
	function companion_wc_loop_shop_per_page( $cols ) {
		$shop_products_per_page = companion_get_option( 'shop_products_per_page' );

		return ( $shop_products_per_page ) ? $shop_products_per_page : '15';
	}
}

add_filter( 'loop_shop_per_page', 'companion_wc_loop_shop_per_page', 20 );

/**
 * Change number of products per row
 */
if ( ! function_exists( 'companion_wc_loop_columns' ) ) {
	function companion_wc_loop_columns( $shop_products_per_row ) {
		$shop_products_per_row = companion_get_option( 'shop_products_per_row' );
		$shop_products_per_row = apply_filters( 'companion_wc_products_per_row', $shop_products_per_row );

		return $shop_products_per_row ? $shop_products_per_row : '3';
	}
}

add_filter( 'loop_shop_columns', 'companion_wc_loop_columns', 999 );

/**
 * Override number of products per row with get query
 */
if ( ! function_exists( 'companion_wc_override_products_per_row' ) ) {
	function companion_wc_override_products_per_row( $shop_products_per_row ) {
		$check_values = array( '2', '3', '4' );

		if ( ! empty( $_GET['columns'] ) && in_array( $_GET['columns'], $check_values ) ) { // phpcs:ignore
			$shop_products_per_row = $_GET['columns']; // phpcs:ignore
		}

		return $shop_products_per_row;
	}
}

add_filter( 'companion_wc_products_per_row', 'companion_wc_override_products_per_row', 100 );

/**
 * Checkout page wrappers
 */
if ( ! function_exists( 'companion_wc_checkout_before_customer_details' ) ) {
	function companion_wc_checkout_before_customer_details() {
		?>
	<div class="companion-wc-checkout">
	<div class="companion-wc-checkout-left">
		<?php
	}
}

add_action( 'woocommerce_checkout_before_customer_details', 'companion_wc_checkout_before_customer_details' );

if ( ! function_exists( 'companion_wc_checkout_after_customer_details' ) ) {
	function companion_wc_checkout_after_customer_details() {
		?>
	</div>
	<div class="companion-wc-checkout-right">
		<?php
	}
}

add_action( 'woocommerce_checkout_after_customer_details', 'companion_wc_checkout_after_customer_details' );

if ( ! function_exists( 'companion_wc_review_order_after_submit' ) ) {
	function companion_wc_review_order_after_submit() {
		?>
	</div>
	</div>
		<?php
	}
}

add_action( 'woocommerce_review_order_after_submit', 'companion_wc_review_order_after_submit' );

/**
 * Login & register page wrappers
 */
if ( ! function_exists( 'companion_wc_before_customer_login_form' ) ) {
	function companion_wc_before_customer_login_form() {
		?>
	<div class="companion-wc-login">
		<?php
	}
}

add_action( 'woocommerce_before_customer_login_form', 'companion_wc_before_customer_login_form' );

if ( ! function_exists( 'companion_wc_after_customer_login_form' ) ) {
	function companion_wc_after_customer_login_form() {
		?>
	</div>
		<?php
	}
}

add_action( 'woocommerce_after_customer_login_form', 'companion_wc_after_customer_login_form' );

/**
 * My account dashboard wrappers
 */
if ( ! function_exists( 'companion_wc_before_account_navigation' ) ) {
	function companion_wc_before_account_navigation() {
		?>
		<div class="companion-wc-account">
		<?php
	}
}

add_action( 'woocommerce_before_account_navigation', 'companion_wc_before_account_navigation' );
