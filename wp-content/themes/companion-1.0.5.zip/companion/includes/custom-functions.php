<?php
/**
 * Content width
 */
if ( ! isset( $content_width ) ) {
	$content_width = 900;
}

/**
 * Add Favicon
 */
if ( ! function_exists( 'companion_get_favicon' ) ) {
	function companion_get_favicon() {
		$favicon = companion_get_option( 'favicon' );
		if ( $favicon ) {
			echo '<link rel="shortcut icon" type="image/x-icon" href="' . esc_url( wp_get_attachment_url( $favicon ) ) . '" />' . "\n";
		} else {
			echo '<link rel="shortcut icon" type="image/x-icon" href="' . esc_url( get_template_directory_uri() ) . '/favicon.png" />' . "\n";
		}
	}
}

add_action( 'wp_head', 'companion_get_favicon' );

if ( ! function_exists( 'companion_admin_favicon' ) ) {
	function companion_admin_favicon() {
		$favicon = companion_get_option( 'favicon' );
		if ( $favicon ) {
			echo '<link rel="shortcut icon" type="image/x-icon" href="' . esc_url( wp_get_attachment_url( $favicon ) ) . '" />' . "\n";
		} else {
			echo '<link rel="shortcut icon" type="image/x-icon" href="' . esc_url( get_template_directory_uri() ) . '/favicon.png" />' . "\n";
		}
	}
}

add_action( 'admin_head', 'companion_admin_favicon' );

function companion_preloader() {
	$preloader = companion_get_option( 'preloader', false );

	if ( $preloader ) : ?>
		<div class="companion-preloader-enable" id="companion-preloader">
			<div class="companion-preloader-spinner"><img
				src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/preloader.svg' ); ?>"
				alt="<?php echo esc_attr__( 'Preloader', 'companion' ); ?>"/>
			</div>
		</div>
		<?php
	endif;
}

add_action( 'wp_body_open', 'companion_preloader' );

/**
 * Setup settings
 */
if ( ! function_exists( 'companion_setup' ) ) {
	function companion_setup() {
		load_theme_textdomain( 'companion', get_template_directory() . '/languages' );
		add_theme_support( 'widgets' );
		add_theme_support( 'automatic-feed-links' );
		add_theme_support( 'title-tag' );
		add_theme_support( 'post-thumbnails' );
		add_theme_support(
			'html5',
			array(
				'search-form',
				'comment-form',
				'comment-list',
				'gallery',
				'caption',
			)
		);

		register_nav_menus(
			array(
				'stm-header-menu' => esc_html__( 'Header menu', 'companion' ),
			)
		);

		add_image_size( 'companion_post_image', 370, 240, true );
		add_image_size( 'companion_single_post_image', 1156, 450, true );
	}
}

add_action( 'after_setup_theme', 'companion_setup' );

/**
 * Add ping back url
 */
function companion_pingback_header() {
	if ( is_singular() && pings_open() ) {
		printf( '<link rel="pingback" href="%s">', esc_url( get_bloginfo( 'pingback_url' ) ) );
	}
}

add_action( 'wp_head', 'companion_pingback_header' );

/**
 * Custom excerpt size
 */
function companion_minimize_word( $word, $length = '40', $affix = '...' ) {
	if ( ! empty( intval( $length ) ) ) {
		$word_length = mb_strlen( $word );
		if ( $word_length > $length ) {
			$word = mb_strimwidth( $word, 0, $length, $affix );
		}
	}

	return sanitize_text_field( $word );
}

function companion_stored_theme_options() {
	$options = get_option( 'stm_theme_settings', array() );

	return apply_filters( 'companion_stored_theme_options', $options );
}

function companion_get_option( $option_name, $default = false ) {
	$options = companion_stored_theme_options();
	$option  = null;

	if ( ! empty( $options[ $option_name ] ) ) {
		$option = $options[ $option_name ];
	} elseif ( isset( $default ) ) {
		$option = $default;
	}

	return $option;
}

function companion_read_more_link() {
	if ( ! is_admin() ) {
		return '<a href="' . esc_url( get_permalink() ) . '" class="more-link"><span class="screen-reader-text">' . esc_html( get_the_title() ) . '</span></a>';
	}
}

add_filter( 'excerpt_more', 'companion_read_more_link' );

function companion_filter_head() {
	remove_action( 'wp_head', '_admin_bar_bump_cb' );
}

add_action( 'get_header', 'companion_filter_head' );

function companion_admin_bar_css() {
	?>
	<style type="text/css" media="screen">
		body {
			margin-top: 32px !important;
		}

		@media screen and (max-width: 782px) {
			body {
				margin-top: 46px !important;
			}
		}
	</style>
	<?php
}

add_theme_support( 'admin-bar', array( 'callback' => 'companion_admin_bar_css' ) );

function companion_widgets_init() {

	$settings = get_option( 'stm_theme_settings', array() );
	if ( isset( $settings['custom_sidebars'] ) && ! empty( $settings['custom_sidebars'] ) ) {
		$custom_sidebars = $settings['custom_sidebars'];
		foreach ( $custom_sidebars as $sidebar ) {
			register_sidebar(
				array(
					'name'          => $sidebar['sidebar_custom'],
					'id'            => lcfirst( $sidebar['sidebar_custom'] ),
					'description'   => esc_html__( 'Add widgets here.', 'companion' ),
					'before_widget' => '<section id="%1$s" class="widget widget-container %2$s">',
					'after_widget'  => '</section>',
					'before_title'  => '<h2 class="widget-title">',
					'after_title'   => '</h2>',
				)
			);
		}
	}
	register_sidebar(
		array(
			'name'          => esc_html__( 'Primary sidebar', 'companion' ),
			'id'            => 'primary-sidebar',
			'description'   => esc_html__( 'Add widgets here.', 'companion' ),
			'before_widget' => '<section id="%1$s" class="widget widget-container %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		)
	);
}

add_action( 'widgets_init', 'companion_widgets_init' );

/**
 * Custom function which will return author tags section depend on theme options
 */
function companion_is_defined_theme_options() {
	return ( ! defined( 'COMPANION_CONFIGURATIONS_VERSION' ) );
}

/**
 * Custom function which will return author tags section depend on theme options
 */
if ( ! function_exists( 'companion_post_author_by_theme_options' ) ) :
	function companion_post_author_by_theme_options( $current_post_type = '', $settings = '' ) {
		if ( ! empty( $settings['author-on-posts-page'] ) || companion_is_defined_theme_options() ) {
			get_template_part( 'templates/single/post/parts/tags' );
			get_template_part( 'templates/single/post/parts/author' );
			get_template_part( 'templates/single/post/parts/share' );
		}
	}
endif;

/**
 * Custom function which will return comment section depend on theme options
 */
if ( ! function_exists( 'companion_post_comments_by_theme_options' ) ) :
	function companion_post_comments_by_theme_options( $current_post_type = '', $settings = '' ) {
		if ( ! empty( $settings['comment-on-posts-page'] ) || companion_is_defined_theme_options() ) {
			get_template_part( 'templates/single/post/parts/comments' );
		}
	}
endif;

/**
 * Custom function which will return post info section depend on theme options
 */
if ( ! function_exists( 'companion_post_info_section_by_theme_options' ) ) :
	function companion_post_info_section_by_theme_options( $option = '' ) {
		$settings = get_option( 'stm_theme_settings', array() );
		if ( ! empty( $settings[ $option ] ) || companion_is_defined_theme_options() ) {
			return true;
		}
	}
endif;

/**
 * Custom function which will return sidebar layout depend on theme options
 */
if ( ! function_exists( 'companion_post_sidebar_by_theme_options' ) ) :
	function companion_post_sidebar_by_theme_options( $settings = '' ) {
		if ( ! empty( $settings['single-posts-sidebar'] ) ) {
			return $settings['single-posts-sidebar'];
		} elseif ( companion_is_defined_theme_options() ) {
			return 'primary-sidebar';
		}
	}
endif;

/**
 * Custom function which will return sidebar position depend on theme options
 */
if ( ! function_exists( 'companion_post_sidebar_position_theme_options' ) ) :
	function companion_post_sidebar_position_theme_options( $current_post_type = '', $settings = '' ) {
		if ( ! empty( $settings['single-posts-sidebar-position'] ) ) {
			return 'sidebar-position-' . $settings['single-posts-sidebar-position'];
		} elseif ( companion_is_defined_theme_options() ) {
			return 'sidebar-position-right';
		}
	}
endif;

/**
 * Custom Pagination
 */
if ( ! function_exists( 'companion_posts_pages_pagination' ) ) :
	function companion_posts_pages_pagination( $paging_extra_class = '', $current_query = '' ) {
		global $wp_query, $wp_rewrite;

		if ( ! $current_query ) {
			$paged = get_query_var( 'paged' ) ? intval( get_query_var( 'paged' ) ) : 1;
			$pages = $wp_query->max_num_pages;
		} else {
			$paged = $current_query->query_vars['paged'];
			$pages = $current_query->max_num_pages;
		}

		if ( $pages < 2 ) {
			return;
		}

		$page_num_link = html_entity_decode( get_pagenum_link() );
		$query_args    = array();
		$url_parts     = explode( '?', $page_num_link );

		if ( isset( $url_parts[1] ) ) {
			wp_parse_str( $url_parts[1], $query_args );
		}

		$page_num_link = remove_query_arg( array_keys( $query_args ), $page_num_link );
		$page_num_link = trailingslashit( $page_num_link ) . '%_%';

		$format  = $wp_rewrite->using_index_permalinks() && ! strpos( $page_num_link, 'index.php' ) ? 'index.php/' : '';
		$format .= $wp_rewrite->using_permalinks() ? user_trailingslashit( $wp_rewrite->pagination_base . '/%#%', 'paged' ) : '?paged=%#%';

		$links = paginate_links(
			array(
				'base'      => $page_num_link,
				'format'    => $format,
				'total'     => $pages,
				'current'   => $paged,
				'mid_size'  => 1,
				'add_args'  => array_map( 'urlencode', $query_args ),
				'prev_text' => '<i aria-hidden="true" class="companion-icon-arrow-left-sharp"></i>',
				'next_text' => '<i aria-hidden="true" class="companion-icon-arrow-right-sharp"></i>',
				'type'      => 'list',
			)
		);

		if ( $links ) {
			echo wp_kses_post( $links );
		}
	}
endif;

/**
 * Elementor Header Footer Builder Position
 */
add_filter(
	'elementor/frontend/builder_content_data',
	function ( $data, $post_id ) {
		$header_position_desktop = get_post_meta( $post_id, 'elementor_hf_position_desktop', true );
		$header_position_tablet  = get_post_meta( $post_id, 'elementor_hf_position_tablet', true );
		$header_position_mobile  = get_post_meta( $post_id, 'elementor_hf_position_mobile', true );

		wp_localize_script(
			'companion-elementor-hf',
			"companion_ehf_position_desktop_{$post_id}",
			array(
				'id'                      => $post_id,
				'header_position_desktop' => $header_position_desktop,
			)
		);

		wp_localize_script(
			'companion-elementor-hf',
			"companion_ehf_position_tablet_{$post_id}",
			array(
				'id'                     => $post_id,
				'header_position_tablet' => $header_position_tablet,
			)
		);

		wp_localize_script(
			'companion-elementor-hf',
			"companion_ehf_position_mobile_{$post_id}",
			array(
				'id'                     => $post_id,
				'header_position_mobile' => $header_position_mobile,
			)
		);

		return $data;
	},
	10,
	2
);
