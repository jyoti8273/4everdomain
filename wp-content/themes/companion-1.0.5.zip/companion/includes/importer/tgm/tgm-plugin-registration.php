<?php

require_once STM_INCLUDES_PATH . '/importer/tgm/tgm-plugin-activation.php';

add_action( 'tgmpa_register', 'companion_install_plugins' );

function companion_install_plugins( $return = false ) {

	$companion_configurations_ver    = '1.0.3';
	$companion_elementor_widgets_ver = '1.0.4';

	$plugins = array(
		'envato-market'               => array(
			'name'     => 'Envato Market',
			'slug'     => 'envato-market',
			'source'   => 'https://envato.github.io/wp-envato-market/dist/envato-market.zip',
			'required' => true,
		),
		'companion-configurations'    => array(
			'name'         => 'Companion Configurations',
			'slug'         => 'companion-configurations',
			'source'       => 'downloads://companion/companion-configurations-' . $companion_configurations_ver . '.zip',
			'required'     => true,
			'version'      => $companion_configurations_ver,
			'external_url' => 'https://stylemixthemes.com/',
			'core'         => true,
		),
		'companion-elementor-widgets' => array(
			'name'         => 'Companion Elementor Widgets',
			'slug'         => 'companion-elementor-widgets',
			'source'       => 'downloads://companion/companion-elementor-widgets-' . $companion_elementor_widgets_ver . '.zip',
			'required'     => true,
			'version'      => $companion_elementor_widgets_ver,
			'external_url' => 'https://stylemixthemes.com/',
			'core'         => true,
		),
		'elementor'                   => array(
			'name'     => 'Elementor',
			'slug'     => 'elementor',
			'required' => true,
		),
		'header-footer-elementor'     => array(
			'name'     => 'Elementor Header & Footer Builder',
			'slug'     => 'header-footer-elementor',
			'required' => false,
		),
		'custom-elementor-icons'      => array(
			'name'     => 'Custom Elementor Icons',
			'slug'     => 'custom-elementor-icons',
			'required' => true,
			'core'     => true,
		),
		'breadcrumb-navxt'            => array(
			'name'     => 'Breadcrumb NavXT',
			'slug'     => 'breadcrumb-navxt',
			'required' => false,
		),
		'contact-form-7'              => array(
			'name'     => 'Contact Form 7',
			'slug'     => 'contact-form-7',
			'required' => false,
		),
		'woocommerce'                 => array(
			'name'     => 'Woocommerce',
			'slug'     => 'woocommerce',
			'required' => false,
		),
		'yith-woocommerce-wishlist'   => array(
			'name'     => 'YITH WooCommerce Wishlist',
			'slug'     => 'yith-woocommerce-wishlist',
			'required' => false,
		),
		'bookit'                      => array(
			'name'     => 'Booking Calendar | BookIt',
			'slug'     => 'bookit',
			'required' => false,
		),
		'mailchimp-for-wp'            => array(
			'name'     => 'MailChimp for WordPress Lite',
			'slug'     => 'mailchimp-for-wp',
			'required' => false,
		),
		'cost-calculator-builder'     => array(
			'name'     => 'Cost Calculator Builder',
			'slug'     => 'cost-calculator-builder',
			'required' => false,
		),
		'eroom-zoom-meetings-webinar' => array(
			'name'     => 'eRoom – Zoom Meetings & Webinar',
			'slug'     => 'eroom-zoom-meetings-webinar',
			'required' => false,
		),
	);

	if ( $return ) {
		return $plugins;
	} else {
		$config = array(
			'id'           => 'pearl_theme_id',
			'is_automatic' => false,
		);

		$layout_plugins      = companion_demo_plugins( companion_get_demo_name() );
		$recommended_plugins = companion_premium_bundled_plugins();
		$layout_plugins      = array_merge( $layout_plugins, $recommended_plugins );

		$tgm_layout_plugins = array();
		foreach ( $layout_plugins as $layout_plugin ) {
			$tgm_layout_plugins[ $layout_plugin ] = $plugins[ $layout_plugin ];
		}

		tgmpa( $tgm_layout_plugins, $config );
	}

}
