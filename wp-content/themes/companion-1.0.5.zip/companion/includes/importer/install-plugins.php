<?php
add_filter( 'stm_theme_plugins', 'companion_get_plugins' );

function companion_get_plugins() {
	return companion_install_plugins( true );
}

function companion_premium_bundled_plugins() {
	return array(
		'envato-market',
	);
}

function companion_demo_plugins( $demo = 'layout_business', $get_demos = false ) {
	$required = array(
		'envato-market',
		'companion-configurations',
		'companion-elementor-widgets',
		'elementor',
		'header-footer-elementor',
		'custom-elementor-icons',
		'breadcrumb-navxt',
		'contact-form-7',
		'woocommerce',
		'yith-woocommerce-wishlist',
		'bookit',
		'mailchimp-for-wp',
		'cost-calculator-builder',
		'eroom-zoom-meetings-webinar',
	);

	$demo_plugins = array(
		'second_demo' => array(
			'breadcrumb-navxt',
		),
	);

	if ( $get_demos ) {
		return $demo_plugins;
	}

	return ( ! empty( $demo_plugins[ $demo ] ) ) ? array_merge( $required, $demo_plugins[ $demo ] ) : $required;
}

add_filter( 'stm_theme_layout_plugins', 'get_stm_theme_layout_plugins', 10, 1 );

function get_stm_theme_layout_plugins( $layout ) {
	return companion_demo_plugins( $layout );
}
