<?php
require_once STM_INCLUDES_PATH . '/importer/demo-selection.php';
require_once STM_INCLUDES_PATH . '/importer/tgm/tgm-plugin-registration.php';
require_once STM_INCLUDES_PATH . '/importer/install-plugins.php';
