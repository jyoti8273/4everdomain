<?php
add_filter( 'stm_theme_demos', 'companion_demo_list' );

function companion_demo_list() {
	return array(
		'layout_business'             => array(
			'label'    => esc_html__( 'Business', 'companion' ),
			'slug'     => 'layout_business',
			'live_url' => 'business/',
		),
		'layout_corporate'            => array(
			'label'    => esc_html__( 'Corporate', 'companion' ),
			'slug'     => 'layout_corporate',
			'live_url' => 'corporate/',
		),
		'layout_hr'                   => array(
			'label'    => esc_html__( 'HR', 'companion' ),
			'slug'     => 'layout_hr',
			'live_url' => 'hr/',
		),
		'layout_marketing_agency'     => array(
			'label'    => esc_html__( 'Marketing Agency', 'companion' ),
			'slug'     => 'layout_marketing_agency',
			'live_url' => 'marketing-agency/',
		),
		'layout_digital_agency'       => array(
			'label'    => esc_html__( 'Digital Agency', 'companion' ),
			'slug'     => 'layout_digital_agency',
			'live_url' => 'digital-agency/',
		),
		'layout_accountant'           => array(
			'label'    => esc_html__( 'Accountant', 'companion' ),
			'slug'     => 'layout_accountant',
			'live_url' => 'accountant/',
		),
		'layout_business_consultant'  => array(
			'label'    => esc_html__( 'Business Consultant', 'companion' ),
			'slug'     => 'layout_business_consultant',
			'live_url' => 'business-consultant/',
		),
		'layout_strategy_consultants' => array(
			'label'    => esc_html__( 'Strategy Consultants', 'companion' ),
			'slug'     => 'layout_strategy_consultants',
			'live_url' => 'strategy-consultants/',
		),
	);
}

add_filter( 'stm_theme_enable_elementor', 'get_stm_theme_enable_elementor' );

function get_stm_theme_enable_elementor() {
	return true;
}

add_filter( 'stm_theme_enable_js_composer', 'stm_theme_enable_js_composer' );

function stm_theme_enable_js_composer() {
	return false;
}
