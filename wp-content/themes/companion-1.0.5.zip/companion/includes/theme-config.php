<?php

function companion_get_demo_name() {
	$demo_name = get_option( 'stm_demo_name', '' );

	return $demo_name;
}

add_filter( 'stm_theme_demo_layout', 'companion_get_demo_name' );

function companion_color_styles() {
	$theme_settings = get_option( 'stm_theme_settings', array() );
	ob_start();
	?>
	:root {
		--primary_color: <?php echo esc_html( ( ! empty( $theme_settings['primary_color'] ) ) ? $theme_settings['primary_color'] : '#A6876A' ); ?>;
		--primary_variant_color: <?php echo esc_html( ( ! empty( $theme_settings['primary_variant_color'] ) ) ? $theme_settings['primary_variant_color'] : '#92643A' ); ?>;
		--secondary_color: <?php echo esc_html( ( ! empty( $theme_settings['secondary_color'] ) ) ? $theme_settings['secondary_color'] : '#0E163D' ); ?>;
		--secondary_variant_color: <?php echo esc_html( ( ! empty( $theme_settings['secondary_variant_color'] ) ) ? $theme_settings['secondary_variant_color'] : '#414562' ); ?>;
		--body_font_family: <?php echo esc_html( ( ! empty( $theme_settings['body_font']['font-family'] ) ) ? $theme_settings['body_font']['font-family'] : 'Merriweather' ); ?>;
		--body_font_weight: <?php echo esc_html( ( ! empty( $theme_settings['body_font']['font-weight'] ) ) ? $theme_settings['body_font']['font-weight'] : '400' ); ?>;
		--body_font_size: <?php echo esc_html( ( ! empty( $theme_settings['body_font']['font-size'] ) ) ? $theme_settings['body_font']['font-size'] . 'px' : '18px' ); ?>;
		--body_line_height: <?php echo ( floatval( ( ! empty( $theme_settings['body_font']['line-height'] ) ) ? $theme_settings['body_font']['line-height'] . 'px' : '30px' ) / floatval( ( ! empty( $theme_settings['body_font']['font-size'] ) ) ? $theme_settings['body_font']['font-size'] . 'px' : '18px' ) ); ?>;
		--body_word_spacing: <?php echo esc_html( ( ! empty( $theme_settings['body_font']['word-spacing'] ) ) ? $theme_settings['body_font']['word-spacing'] . 'px' : '0' ); ?>;
		--body_letter_spacing: <?php echo esc_html( ( ! empty( $theme_settings['body_font']['letter-spacing'] ) ) ? $theme_settings['body_font']['letter-spacing'] . 'px' : '0' ); ?>;
		--secondary_font_family: <?php echo esc_html( ( ! empty( $theme_settings['secondary_font']['font-family'] ) ) ? $theme_settings['secondary_font']['font-family'] : 'DM Sans' ); ?>;
		--secondary_font_weight: <?php echo esc_html( ( ! empty( $theme_settings['secondary_font']['font-weight'] ) ) ? $theme_settings['secondary_font']['font-weight'] : '400' ); ?>;
		--h1_font_family: <?php echo esc_html( ( ! empty( $theme_settings['h1_font']['font-family'] ) ) ? $theme_settings['h1_font']['font-family'] : 'DM Sans' ); ?>;
		--h1_font_weight: <?php echo esc_html( ( ! empty( $theme_settings['h1_font']['font-weight'] ) ) ? $theme_settings['h1_font']['font-weight'] : '700' ); ?>;
		--h1_font_size: <?php echo esc_html( ( ! empty( $theme_settings['h1_font']['font-size'] ) ) ? $theme_settings['h1_font']['font-size'] . 'px' : '60px' ); ?>;
		--h1_line_height: <?php echo esc_html( ( ! empty( $theme_settings['h1_font']['line-height'] ) ) ? $theme_settings['h1_font']['line-height'] . 'px' : '66px' ); ?>;
		--h1_word_spacing: <?php echo esc_html( ( ! empty( $theme_settings['h1_font']['word-spacing'] ) ) ? $theme_settings['h1_font']['word-spacing'] . 'px' : '0' ); ?>;
		--h1_letter_spacing: <?php echo esc_html( ( ! empty( $theme_settings['h1_font']['letter-spacing'] ) ) ? $theme_settings['h1_font']['letter-spacing'] . 'px' : '-2.4px' ); ?>;
		--h2_font_family: <?php echo esc_html( ( ! empty( $theme_settings['h2_font']['font-family'] ) ) ? $theme_settings['h2_font']['font-family'] : 'DM Sans' ); ?>;
		--h2_font_weight: <?php echo esc_html( ( ! empty( $theme_settings['h2_font']['font-weight'] ) ) ? $theme_settings['h2_font']['font-weight'] : '700' ); ?>;
		--h2_font_size: <?php echo esc_html( ( ! empty( $theme_settings['h2_font']['font-size'] ) ) ? $theme_settings['h2_font']['font-size'] . 'px' : '48px' ); ?>;
		--h2_line_height: <?php echo esc_html( ( ! empty( $theme_settings['h2_font']['line-height'] ) ) ? $theme_settings['h2_font']['line-height'] . 'px' : '54px' ); ?>;
		--h2_word_spacing: <?php echo esc_html( ( ! empty( $theme_settings['h2_font']['word-spacing'] ) ) ? $theme_settings['h2_font']['word-spacing'] . 'px' : '0' ); ?>;
		--h2_letter_spacing: <?php echo esc_html( ( ! empty( $theme_settings['h2_font']['letter-spacing'] ) ) ? $theme_settings['h2_font']['letter-spacing'] . 'px' : '-1.2px' ); ?>;
		--h3_font_family: <?php echo esc_html( ( ! empty( $theme_settings['h3_font']['font-family'] ) ) ? $theme_settings['h3_font']['font-family'] : 'DM Sans' ); ?>;
		--h3_font_weight: <?php echo esc_html( ( ! empty( $theme_settings['h3_font']['font-weight'] ) ) ? $theme_settings['h3_font']['font-weight'] : '700' ); ?>;
		--h3_font_size: <?php echo esc_html( ( ! empty( $theme_settings['h3_font']['font-size'] ) ) ? $theme_settings['h3_font']['font-size'] . 'px' : '42px' ); ?>;
		--h3_line_height: <?php echo esc_html( ( ! empty( $theme_settings['h3_font']['line-height'] ) ) ? $theme_settings['h3_font']['line-height'] . 'px' : '48px' ); ?>;
		--h3_word_spacing: <?php echo esc_html( ( ! empty( $theme_settings['h3_font']['word-spacing'] ) ) ? $theme_settings['h3_font']['word-spacing'] . 'px' : '0' ); ?>;
		--h3_letter_spacing: <?php echo esc_html( ( ! empty( $theme_settings['h3_font']['letter-spacing'] ) ) ? $theme_settings['h3_font']['letter-spacing'] . 'px' : '-0.84px' ); ?>;
		--h4_font_family: <?php echo esc_html( ( ! empty( $theme_settings['h4_font']['font-family'] ) ) ? $theme_settings['h4_font']['font-family'] : 'DM Sans' ); ?>;
		--h4_font_weight: <?php echo esc_html( ( ! empty( $theme_settings['h4_font']['font-weight'] ) ) ? $theme_settings['h4_font']['font-weight'] : '700' ); ?>;
		--h4_font_size: <?php echo esc_html( ( ! empty( $theme_settings['h4_font']['font-size'] ) ) ? $theme_settings['h4_font']['font-size'] . 'px' : '30px' ); ?>;
		--h4_line_height: <?php echo esc_html( ( ! empty( $theme_settings['h4_font']['line-height'] ) ) ? $theme_settings['h4_font']['line-height'] . 'px' : '36px' ); ?>;
		--h4_word_spacing: <?php echo esc_html( ( ! empty( $theme_settings['h4_font']['word-spacing'] ) ) ? $theme_settings['h4_font']['word-spacing'] . 'px' : '0' ); ?>;
		--h4_letter_spacing: <?php echo esc_html( ( ! empty( $theme_settings['h4_font']['letter-spacing'] ) ) ? $theme_settings['h4_font']['letter-spacing'] . 'px' : '-0.44px' ); ?>;
		--h5_font_family: <?php echo esc_html( ( ! empty( $theme_settings['h5_font']['font-family'] ) ) ? $theme_settings['h5_font']['font-family'] : 'DM Sans' ); ?>;
		--h5_font_weight: <?php echo esc_html( ( ! empty( $theme_settings['h5_font']['font-weight'] ) ) ? $theme_settings['h5_font']['font-weight'] : '700' ); ?>;
		--h5_font_size: <?php echo esc_html( ( ! empty( $theme_settings['h5_font']['font-size'] ) ) ? $theme_settings['h5_font']['font-size'] . 'px' : '24px' ); ?>;
		--h5_line_height: <?php echo esc_html( ( ! empty( $theme_settings['h5_font']['line-height'] ) ) ? $theme_settings['h5_font']['line-height'] . 'px' : '30px' ); ?>;
		--h5_word_spacing: <?php echo esc_html( ( ! empty( $theme_settings['h5_font']['word-spacing'] ) ) ? $theme_settings['h5_font']['word-spacing'] . 'px' : '0' ); ?>;
		--h5_letter_spacing: <?php echo esc_html( ( ! empty( $theme_settings['h5_font']['letter-spacing'] ) ) ? $theme_settings['h5_font']['letter-spacing'] . 'px' : '-0.24px' ); ?>;
		--h6_font_family: <?php echo esc_html( ( ! empty( $theme_settings['h6_font']['font-family'] ) ) ? $theme_settings['h6_font']['font-family'] : 'DM Sans' ); ?>;
		--h6_font_weight: <?php echo esc_html( ( ! empty( $theme_settings['h6_font']['font-weight'] ) ) ? $theme_settings['h6_font']['font-weight'] : '700' ); ?>;
		--h6_font_size: <?php echo esc_html( ( ! empty( $theme_settings['h6_font']['font-size'] ) ) ? $theme_settings['h6_font']['font-size'] . 'px' : '18px' ); ?>;
		--h6_line_height: <?php echo esc_html( ( ! empty( $theme_settings['h6_font']['line-height'] ) ) ? $theme_settings['h6_font']['line-height'] . 'px' : '24px' ); ?>;
		--h6_word_spacing: <?php echo esc_html( ( ! empty( $theme_settings['h6_font']['word-spacing'] ) ) ? $theme_settings['h6_font']['word-spacing'] . 'px' : '0' ); ?>;
		--h6_letter_spacing: <?php echo esc_html( ( ! empty( $theme_settings['h6_font']['letter-spacing'] ) ) ? $theme_settings['h6_font']['letter-spacing'] . 'px' : '-0.09px' ); ?>;
	}
	<?php
	$css = ob_get_contents();
	ob_end_clean();
	return $css;
}

function companion_theme_activation() {
	if ( empty( get_option( 'stm_theme_settings', '' ) ) ) {
		global $wp_filesystem;
		require_once ABSPATH . '/wp-admin/includes/file.php';
		WP_Filesystem();

		$json_path          = wp_normalize_path( dirname( dirname( __FILE__ ) ) . '/includes/config.json' );
		$theme_options_json = '';

		if ( is_wp_error( $wp_filesystem ) || is_wp_error( $wp_filesystem->errors ) ) {
			$theme_options_json = $wp_filesystem->get_contents( $json_path );
		}

		update_option( 'stm_theme_settings', json_decode( $theme_options_json, true ) );
	}
}

add_action( 'after_switch_theme', 'companion_theme_activation' );

function companion_theme_fonts() {
	$settings = get_option( 'stm_theme_settings', array() );

	$fonts         = array();
	$heading_fonts = array(
		'h1_font',
		'h2_font',
		'h3_font',
		'h4_font',
		'h5_font',
		'h6_font',
	);

	foreach ( $heading_fonts as $heading_font ) {
		if ( ! empty( $settings[ $heading_font ]['font-family'] ) ) {
			$fonts[] = "{$settings[$heading_font]['font-family']}:{$settings[$heading_font]['font-weight']}";
			$fonts[] = "{$settings[$heading_font]['font-family']}:{$settings[$heading_font]['font-weight']}i";
		} else {
			$fonts[] = 'DM Sans:700,500,400';
		}
	}

	if ( ! empty( $settings['body_font']['font-family'] ) ) {
		$fonts[] = "{$settings['body_font']['font-family']}:{$settings['body_font']['font-weight']}";
		$fonts[] = "{$settings['body_font']['font-family']}:{$settings['body_font']['font-weight']}i";
		$fonts[] = "{$settings['body_font']['font-family']}:700";
		$fonts[] = "{$settings['body_font']['font-family']}:700i";
	} else {
		$fonts[] = 'Merriweather:700,400';
	}

	if ( ! empty( $settings['secondary_font']['font-family'] ) ) {
		$fonts[] = "{$settings['secondary_font']['font-family']}:{$settings['secondary_font']['font-weight']}";
		$fonts[] = "{$settings['secondary_font']['font-family']}:{$settings['secondary_font']['font-weight']}i";
		$fonts[] = "{$settings['secondary_font']['font-family']}:700";
		$fonts[] = "{$settings['secondary_font']['font-family']}:700i";
	} else {
		$fonts[] = 'DM Sans:700,400';
	}

	$subsets = apply_filters( 'google_fonts_subset', 'latin,latin-ext' );

	$query_args = array(
		'family' => rawurlencode( implode( '|', array_unique( $fonts ) ) ),
		'subset' => rawurlencode( $subsets ),
	);

	$fonts_url = ( ! empty( $fonts ) ) ? add_query_arg( $query_args, 'https://fonts.googleapis.com/css' ) : '';

	return esc_url( $fonts_url );
}

add_action( 'init', 'companion_theme_fonts' );
