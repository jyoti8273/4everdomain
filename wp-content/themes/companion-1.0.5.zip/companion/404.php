<?php get_header();
$page_title         = ( companion_get_option( '404_title' ) ) ? companion_get_option( '404_title' ) : esc_html__( 'We couldn’t find the page you’re looking for', 'companion' );
$button_link        = ( companion_get_option( '404_button_link' ) ) ? companion_get_option( '404_button_link' ) : get_home_url( '/' );
$button_text        = ( companion_get_option( '404_button_text' ) ) ? companion_get_option( '404_button_text' ) : esc_html__( 'Go home', 'companion' );
$background_image   = ( companion_get_option( '404_background_image' ) ) ? wp_get_attachment_image_src( companion_get_option( '404_background_image' ), 'full' )[0] : get_template_directory_uri() . '/assets/images/404.jpg';
$background_overlay = companion_get_option( '404_background_overlay' );
?>
	<div class="page-404 not-found" style="background-image: url('<?php echo esc_url( $background_image ); ?>');">
		<div class="page-404-overlay" style="background-color: <?php echo esc_attr( $background_overlay ); ?>;"></div>
		<div class="page-404-content">
			<div class="page-404-error">404</div>
			<h1 class="page-404-title">
				<?php echo esc_html( $page_title ); ?>
			</h1>
			<a href="<?php echo esc_url( $button_link ); ?>" class="page-404-button">
				<?php echo esc_html( $button_text ); ?>
			</a>
		</div>
	</div>
<?php
wp_footer();
