{
    "icons" : [
        "flaticon-analysis",
        "flaticon-megaphone",
        "flaticon-software-development",
        "flaticon-graph",
        "flaticon-briefcase-1",
        "flaticon-api-8"
    ]
}