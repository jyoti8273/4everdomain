{
    "icons" : [
        "ti-arrow-up"
    ]
}