<?php 

if (!defined('ABSPATH')) {
    exit;
} // Exit if accessed directly